module.exports = Object.freeze({
    BASE_URL: `https://testing.pogo91.com/api/online-store`
})